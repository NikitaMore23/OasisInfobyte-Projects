//Vaishnavi Shankar Shinde
//java programming


package Number_Game;

import java.io.*;
import java.util.*;
public class number_game{
	
	public static void Number_game()
	{
		Scanner s1 = new Scanner(System.in);
		System.out.print("Enter Range :");
		int n=s1.nextInt();
		int num=1+(int)(n*Math.random()); 
		int rounds=5;
		int guess,i,again,points=0;
		
		System.out.println("Welcome To Number Guessing Game !!!!!");
		//System.out.println("Input a number between 1 to 100");
		
		
		
		for(i=0;i<5;i++) {
			//Take input for guessing
			System.out.print("\nTry to Guess a number.. : ");
			guess=s1.nextInt();
			
			//If the number is guessed...
			if(guess==num) 
			{
				System.out.println("Congrats!! You guessed right");
				points+=10;
				System.out.println("Your score is "+points);
			}

			else if(guess>n || guess<0) {
				System.out.println("Your Number is Between 0 to "+n);
			}
			else if (guess>num && i!=rounds-1) {
				System.out.println("The Number is less than"+guess+"!!!!!");
			}
			else if(guess<num && i!=rounds-1) {
				System.out.println("The Number is greater than"+guess+"!!!!!");
			}
		}
		
		if(rounds==i) {
			System.out.println("\nyou have completed round");
			System.out.println("\nThe number was "+num);
			System.out.println("\n\nDo you want to continue..");
			System.out.println("Enter 1 for continue...");
			again=s1.nextInt();
			
			
			if(again==1) {
				Number_game();   //this will call function again and start game again
			}
			else {
				System.out.println("Thank You!! See You Again....");
			}
		}
		
	}
	public static void main(String[] args) {
		Number_game();
	}
}



import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Atm_Interface{
	DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
	LocalDateTime now =LocalDateTime.now();  
    float bal=0f;
    int trans=0;
    String transHis="";
    String password;
    String act_no;
    String name;
    String userID;
    Scanner sc=new Scanner(System.in); 
    
	public void register(){
        System.out.println("\nENTER YOUR USER NAME  :");
        this.userID=sc.nextLine();
        System.out.println("ENTER YOUR PASSWORD  :");
        this.password=sc.nextLine();
        System.out.println("ENTER YOUR ACCOUNT NUMBER  :");
        this.act_no=sc.nextLine();
        System.out.println("Registration completed. Successfully!!");
        System.out.println("Kindly login to your account.");
    }
	
	
    public boolean login(){
        boolean isLogin=false;
        while(!isLogin){
            System.out.println("\nEnter username : ");
            String usr=sc.nextLine();
            if (usr.equals(userID)){
                System.out.println("Enter password : ");
                String pd=sc.nextLine();
                while(!isLogin){
                    if(pd.equals(password)){
                        System.out.println("Logged-in Successfully!!");
                        isLogin=true;
                    }
                    else{
                        System.out.println("Invalid login!!");
                        break;
                    }
                }
            }
            else{
                System.out.println("Username not found!!");
            }
        }
        return isLogin;
    }
    
    
    public void deposit(){
        System.out.println("\nEnter amount to deposit : ");
        float damount=sc.nextFloat();
        try{
            if(damount<=100000f){
                bal+=damount;
                trans+=1;
                System.out.println("Successfully deposited Rs. "+damount+" at "+dtf.format(now));
                String s="Rs "+damount+" deposited at "+dtf.format(now)+" .\n";
                transHis=transHis.concat(s);
            }
            else{
                System.out.println("Sorry!Can't deposit more than one lakh");
            }
        }
        catch(Exception e){
        }
    }
    
    
    public void withdraw(){
        System.out.println("\nEnter amount to withdraw : ");
        float wamount=sc.nextFloat();
        try{
            if (wamount<=bal){
                bal-=wamount;
                trans+=1;
                System.out.println("Successfully withdrawn Rs. "+wamount+" at "+dtf.format(now));
                String s="Rs "+wamount+" withdrawn at "+dtf.format(now)+" .\n";
                transHis=transHis.concat(s);
            }
            else{
                System.out.println("Sorry!Can't withdraw.Insufficient amount to withdraw..");
            }
        }
        catch(Exception e){
        }
    }
    
    
    
    public void transfer(){
    	Scanner in=new Scanner(System.in);
        System.out.println("\nEnter the username you want to transfer to : ");
        String uname=in.nextLine();
        System.out.println("Enter the amount to transfer");
        float tamount=sc.nextFloat();
        try{
            if (tamount<=bal){
                bal-=tamount;
                trans+=1;
                System.out.println("Successfully transferred Rs. "+tamount+" at "+dtf.format(now));
                String s="Rs "+tamount+" transferred to "+uname+" account at "+dtf.format(now)+" .\n";
                transHis=transHis.concat(s);
            }
            else{
                System.out.println("Sorry!Can't transfer.Insufficient amount to transfer..");
            }
        }   
        catch(Exception e){
        }
    }
    
    
    
    public void transHistory(){
        if(trans==0){
            System.out.println("\nNo Transactions!!");
        }
        else{
            System.out.println("\n"+transHis);
        }
    }
    
    
    public void checkBal(){
        System.out.println("\nBalance amount is : "+bal);
    }
	
	
	
    public static void main(String args[]){
        System.out.println("WELCOME TO ATM!!!");
        System.out.println("\nSelect any one option!");
        System.out.println("1.REGISTER\n12EXIT");
        System.out.println("Enter your option :");
        Scanner sc=new Scanner(System.in);
        int ch;
        ch=sc.nextInt();
        if (ch==1){
        	Atm_Interface Atm=new Atm_Interface();
            Atm.register();
            while(ch==1){
                System.out.println("\nSelect any one option!");
                System.out.println("1.LOGIN\n2.EXIT");
                System.out.println("Enter your option :");
                int op=sc.nextInt();
                if (op==1){
                    if(Atm.login()){
                        boolean isFin=false;
                        while(!isFin){
                            System.out.println("\nSelect any option : ");
                            System.out.println("1.DEPOSIT\n2.WITHDRAW\n3.TRANSFER\n4.TRANSACTION HISTORY\n5.CHECK BALANCE\n6.EXIT");
                            System.out.println("Enter your option :");
                            int c=sc.nextInt();
                            switch(c){
                                case 1 : Atm.deposit();
                                         break;
                                case 2 : Atm.withdraw();
                                         break;
                                case 3 : Atm.transfer();
                                         break;
                                case 4 : Atm.transHistory();
                                         break;
                                case 5 : Atm.checkBal();
                                         break;
                                case 6 : isFin=true;
                                         break;
                                default: System.out.println("Invalid option!");
                            }
                        }
                    }
                }
                else{
                    System.exit(0);
                }
            }
        }
        else {
        	System.out.print("Please Collect Your Card \n Byee");
        	System.exit(0);
        }
    }
}




import java.io.*;
import java.util.*;
public class Online_Exams {
Scanner input=new Scanner(System.in);
HashMap<String,Integer> data=new HashMap<String,Integer>();
	
	public void login() {
		data.put("Madhav",1234);
		data.put("Maddy",2345);
		System.out.println("\n\n-----Welcome to online exam portal-----");
		String userid;
		int pwd;
		System.out.println("Login to continue.....");
		System.out.print("Enter user id : ");
		userid=input.next();
		System.out.print("Enter password : ");
		pwd=input.nextInt();
		if(data.containsKey(userid) && data.get(userid)==pwd) {
			System.out.println("Login sucessful");
				option_menu();
		}
		else {
			System.out.println("SORRY!!! Invalid Login");
			System.out.println("Try again");
				login();
		}
	}
	public void option_menu() {
		int select;
		System.out.println("Enter the option you want to perform");
		System.out.println("1.Update profile and password");
		System.out.println("2.Start the exam");
		System.out.println("3.Logout");
		select=input.nextInt();
		switch(select) {
		case 1:
			data=update();
			option_menu();
			break;
		case 2:
			exam_que();
			option_menu();
			break;
		case 3:
			System.exit(0);
			break;
		default:
			System.out.println("Invalid entry");
		}
	}
	public HashMap<String,Integer> update(){
		String uuser;
		int upwd;
		System.out.println("Welcome to Update profile");
		System.out.println("Enter user name");
		uuser=input.next();
		if(data.containsKey(uuser)) {
		System.out.println("Enter new password you to want to update to your profile");
		upwd = input.nextInt();
		data.replace(uuser, upwd);
		}
		else {
			System.out.println("User doesn't exist");
		}
		return data;
	}
public void exam_que() {
	long examtime=System.currentTimeMillis();
	long endtime=examtime+30;
	int ans_count=0;
	int ans,score;
	System.out.println("Start the exam");
	
	//Question Start From Here 
	
	while(System.currentTimeMillis()<endtime) {
		System.out.println("You have 30 seconds to answer 5 questions");
		System.out.println("Each question carries 10 marks"+" "+"-5 for wrong answer");
		System.out.println("\n\nQ1. What is the extension of java code files ?");
		System.out.println("\n1).js"+"\t"+"2).java"+"\t"+"3).txt"+"\t"+"4).html");
		System.out.println("Enter correct option");
		ans=input.nextInt();
		System.out.println("Answer Locked...");
		if(ans==2) {
			ans_count++;
		}
		System.out.println("\n\nWhich component is used to compile, debug and execute the java programs?");
		System.out.println("1)JRE"+"\t"+"2)JDK"+"\t"+"3)JVM"+"\t"+"4)JIT");
		System.out.println("Enter correct option");
		ans=input.nextInt();
		System.out.println("Answer Locked...");
		if(ans==2) {
			ans_count++;
		}
		System.out.println("\n\nWho invented Java Programming?");
		System.out.println("1)James Gosling"+"\t"+"2)Bjarne Stroustrup"+"\t"+"3)Guido van Rossum"+"\t"+"4)Dennis Ritchie");
		System.out.println("Enter correct option");
		ans=input.nextInt();
		System.out.println("Answer Locked...");
		if(ans==1) {
			ans_count++;
		}
		System.out.println("\n\nWhich one of the following is not a Java feature?");
		System.out.println("1) Dynamic and Extensible"+"\t"+"2) Portable"+"\t"+"3) Object-oriented"+"\t"+"4) Use of pointers");
		System.out.println("Enter correct option");
		ans=input.nextInt();
		System.out.println("Answer Locked...");
		if(ans==4) {
			ans_count++;
		}
		System.out.println("\n\nWhich of the following is not an OOPS concept in Java?");
		System.out.println("1) Compilation"+"\t"+"2) Encapsulation"+"\t"+"3) Inheritance"+"\t"+"4) Polymorphism");
		System.out.println("Enter correct option");
		ans=input.nextInt();
		System.out.println("Answer Locked...");
		if(ans==1) {
			ans_count++;
		}
		break;
	}
	System.out.println("You have finished the exam");
	score=ans_count*10-((5-ans_count)*5); //Score Counting 
	System.out.println("Your score is..."+" "+score+"/50");	
}

public static void main (String[] args)
{
	Online_Exams log =new Online_Exams();
		log.login(); //function calling
}
}